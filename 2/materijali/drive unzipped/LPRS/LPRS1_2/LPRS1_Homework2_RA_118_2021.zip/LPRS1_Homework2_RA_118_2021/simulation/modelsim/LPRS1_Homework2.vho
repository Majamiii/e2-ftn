-- Copyright (C) 2018  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel FPGA IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Intel and sold by Intel or its authorized distributors.  Please
-- refer to the applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 18.1.0 Build 625 09/12/2018 SJ Lite Edition"

-- DATE "11/23/2022 17:14:07"

-- 
-- Device: Altera 10M16SAU169C8G Package UFBGA169
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY FIFTYFIVENM;
LIBRARY IEEE;
USE FIFTYFIVENM.FIFTYFIVENM_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	hard_block IS
    PORT (
	devoe : IN std_logic;
	devclrn : IN std_logic;
	devpor : IN std_logic
	);
END hard_block;

-- Design Ports Information
-- ~ALTERA_TMS~	=>  Location: PIN_G1,	 I/O Standard: 3.3 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TCK~	=>  Location: PIN_G2,	 I/O Standard: 3.3 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TDI~	=>  Location: PIN_F5,	 I/O Standard: 3.3 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TDO~	=>  Location: PIN_F6,	 I/O Standard: 3.3-V LVCMOS,	 Current Strength: Default
-- ~ALTERA_CONFIG_SEL~	=>  Location: PIN_D7,	 I/O Standard: 3.3-V LVCMOS,	 Current Strength: Default
-- ~ALTERA_nCONFIG~	=>  Location: PIN_E7,	 I/O Standard: 3.3 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_nSTATUS~	=>  Location: PIN_C4,	 I/O Standard: 3.3 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_CONF_DONE~	=>  Location: PIN_C5,	 I/O Standard: 3.3 V Schmitt Trigger,	 Current Strength: Default


ARCHITECTURE structure OF hard_block IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL \~ALTERA_TMS~~padout\ : std_logic;
SIGNAL \~ALTERA_TCK~~padout\ : std_logic;
SIGNAL \~ALTERA_TDI~~padout\ : std_logic;
SIGNAL \~ALTERA_CONFIG_SEL~~padout\ : std_logic;
SIGNAL \~ALTERA_nCONFIG~~padout\ : std_logic;
SIGNAL \~ALTERA_nSTATUS~~padout\ : std_logic;
SIGNAL \~ALTERA_CONF_DONE~~padout\ : std_logic;
SIGNAL \~ALTERA_TMS~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_TCK~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_TDI~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_CONFIG_SEL~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_nCONFIG~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_nSTATUS~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_CONF_DONE~~ibuf_o\ : std_logic;

BEGIN

ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;
END structure;


LIBRARY ALTERA;
LIBRARY FIFTYFIVENM;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE FIFTYFIVENM.FIFTYFIVENM_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	lprs1_homework2_for_board IS
    PORT (
	i_clk : IN std_logic;
	in_rst : IN std_logic;
	o_led : BUFFER std_logic_vector(7 DOWNTO 0);
	o_sem_r : BUFFER std_logic;
	o_sem_y : BUFFER std_logic;
	o_sem_g : BUFFER std_logic;
	o_n_col_0_or_7segm_a : BUFFER std_logic;
	o_n_col_1_or_7segm_b : BUFFER std_logic;
	o_n_col_2_or_7segm_c : BUFFER std_logic;
	o_n_col_3_or_7segm_d : BUFFER std_logic;
	o_n_col_4_or_7segm_e : BUFFER std_logic;
	o_n_col_5_or_7segm_f : BUFFER std_logic;
	o_n_col_6_or_7segm_g : BUFFER std_logic;
	o_n_col_7_or_7segm_dp : BUFFER std_logic;
	o_mux_row_or_digit : BUFFER std_logic_vector(2 DOWNTO 0);
	o_mux_sel_color_or_7segm : BUFFER std_logic_vector(1 DOWNTO 0);
	i_sw : IN std_logic_vector(7 DOWNTO 0);
	i_pb_up : IN std_logic;
	i_pb_center : IN std_logic;
	i_pb_down : IN std_logic;
	i_pb_left : IN std_logic;
	i_pb_right : IN std_logic;
	i_pb_rst : IN std_logic
	);
END lprs1_homework2_for_board;

-- Design Ports Information
-- o_led[0]	=>  Location: PIN_A8,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- o_led[1]	=>  Location: PIN_A9,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- o_led[2]	=>  Location: PIN_A11,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- o_led[3]	=>  Location: PIN_A10,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- o_led[4]	=>  Location: PIN_B10,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- o_led[5]	=>  Location: PIN_C9,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- o_led[6]	=>  Location: PIN_C10,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- o_led[7]	=>  Location: PIN_D8,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- o_sem_r	=>  Location: PIN_H13,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- o_sem_y	=>  Location: PIN_E4,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- o_sem_g	=>  Location: PIN_B1,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- o_n_col_0_or_7segm_a	=>  Location: PIN_H8,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- o_n_col_1_or_7segm_b	=>  Location: PIN_K10,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- o_n_col_2_or_7segm_c	=>  Location: PIN_H5,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- o_n_col_3_or_7segm_d	=>  Location: PIN_H4,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- o_n_col_4_or_7segm_e	=>  Location: PIN_J1,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- o_n_col_5_or_7segm_f	=>  Location: PIN_J2,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- o_n_col_6_or_7segm_g	=>  Location: PIN_L12,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- o_n_col_7_or_7segm_dp	=>  Location: PIN_J12,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- o_mux_row_or_digit[0]	=>  Location: PIN_J13,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- o_mux_row_or_digit[1]	=>  Location: PIN_K11,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- o_mux_row_or_digit[2]	=>  Location: PIN_K12,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- o_mux_sel_color_or_7segm[0]	=>  Location: PIN_J10,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- o_mux_sel_color_or_7segm[1]	=>  Location: PIN_H10,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 8mA
-- i_pb_down	=>  Location: PIN_C1,	 I/O Standard: 3.3 V Schmitt Trigger,	 Current Strength: Default
-- i_pb_right	=>  Location: PIN_E3,	 I/O Standard: 3.3 V Schmitt Trigger,	 Current Strength: Default
-- i_sw[0]	=>  Location: PIN_M3,	 I/O Standard: 3.3 V Schmitt Trigger,	 Current Strength: Default
-- i_sw[1]	=>  Location: PIN_L3,	 I/O Standard: 3.3 V Schmitt Trigger,	 Current Strength: Default
-- i_sw[2]	=>  Location: PIN_M2,	 I/O Standard: 3.3 V Schmitt Trigger,	 Current Strength: Default
-- i_sw[3]	=>  Location: PIN_M1,	 I/O Standard: 3.3 V Schmitt Trigger,	 Current Strength: Default
-- i_sw[4]	=>  Location: PIN_N3,	 I/O Standard: 3.3 V Schmitt Trigger,	 Current Strength: Default
-- i_sw[5]	=>  Location: PIN_N2,	 I/O Standard: 3.3 V Schmitt Trigger,	 Current Strength: Default
-- i_sw[6]	=>  Location: PIN_K2,	 I/O Standard: 3.3 V Schmitt Trigger,	 Current Strength: Default
-- i_sw[7]	=>  Location: PIN_K1,	 I/O Standard: 3.3 V Schmitt Trigger,	 Current Strength: Default
-- i_pb_up	=>  Location: PIN_E1,	 I/O Standard: 3.3 V Schmitt Trigger,	 Current Strength: Default
-- i_pb_center	=>  Location: PIN_C2,	 I/O Standard: 3.3 V Schmitt Trigger,	 Current Strength: Default
-- i_pb_left	=>  Location: PIN_D1,	 I/O Standard: 3.3 V Schmitt Trigger,	 Current Strength: Default
-- i_clk	=>  Location: PIN_H6,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- in_rst	=>  Location: PIN_E6,	 I/O Standard: 3.3 V Schmitt Trigger,	 Current Strength: Default
-- i_pb_rst	=>  Location: PIN_F1,	 I/O Standard: 3.3 V Schmitt Trigger,	 Current Strength: Default


ARCHITECTURE structure OF lprs1_homework2_for_board IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_i_clk : std_logic;
SIGNAL ww_in_rst : std_logic;
SIGNAL ww_o_led : std_logic_vector(7 DOWNTO 0);
SIGNAL ww_o_sem_r : std_logic;
SIGNAL ww_o_sem_y : std_logic;
SIGNAL ww_o_sem_g : std_logic;
SIGNAL ww_o_n_col_0_or_7segm_a : std_logic;
SIGNAL ww_o_n_col_1_or_7segm_b : std_logic;
SIGNAL ww_o_n_col_2_or_7segm_c : std_logic;
SIGNAL ww_o_n_col_3_or_7segm_d : std_logic;
SIGNAL ww_o_n_col_4_or_7segm_e : std_logic;
SIGNAL ww_o_n_col_5_or_7segm_f : std_logic;
SIGNAL ww_o_n_col_6_or_7segm_g : std_logic;
SIGNAL ww_o_n_col_7_or_7segm_dp : std_logic;
SIGNAL ww_o_mux_row_or_digit : std_logic_vector(2 DOWNTO 0);
SIGNAL ww_o_mux_sel_color_or_7segm : std_logic_vector(1 DOWNTO 0);
SIGNAL ww_i_sw : std_logic_vector(7 DOWNTO 0);
SIGNAL ww_i_pb_up : std_logic;
SIGNAL ww_i_pb_center : std_logic;
SIGNAL ww_i_pb_down : std_logic;
SIGNAL ww_i_pb_left : std_logic;
SIGNAL ww_i_pb_right : std_logic;
SIGNAL ww_i_pb_rst : std_logic;
SIGNAL \~QUARTUS_CREATED_ADC1~_CHSEL_bus\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \i_clk~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \i_pb_down~input_o\ : std_logic;
SIGNAL \i_pb_right~input_o\ : std_logic;
SIGNAL \~QUARTUS_CREATED_GND~I_combout\ : std_logic;
SIGNAL \~QUARTUS_CREATED_UNVM~~busy\ : std_logic;
SIGNAL \~QUARTUS_CREATED_ADC1~~eoc\ : std_logic;
SIGNAL \o_led[0]~output_o\ : std_logic;
SIGNAL \o_led[1]~output_o\ : std_logic;
SIGNAL \o_led[2]~output_o\ : std_logic;
SIGNAL \o_led[3]~output_o\ : std_logic;
SIGNAL \o_led[4]~output_o\ : std_logic;
SIGNAL \o_led[5]~output_o\ : std_logic;
SIGNAL \o_led[6]~output_o\ : std_logic;
SIGNAL \o_led[7]~output_o\ : std_logic;
SIGNAL \o_sem_r~output_o\ : std_logic;
SIGNAL \o_sem_y~output_o\ : std_logic;
SIGNAL \o_sem_g~output_o\ : std_logic;
SIGNAL \o_n_col_0_or_7segm_a~output_o\ : std_logic;
SIGNAL \o_n_col_1_or_7segm_b~output_o\ : std_logic;
SIGNAL \o_n_col_2_or_7segm_c~output_o\ : std_logic;
SIGNAL \o_n_col_3_or_7segm_d~output_o\ : std_logic;
SIGNAL \o_n_col_4_or_7segm_e~output_o\ : std_logic;
SIGNAL \o_n_col_5_or_7segm_f~output_o\ : std_logic;
SIGNAL \o_n_col_6_or_7segm_g~output_o\ : std_logic;
SIGNAL \o_n_col_7_or_7segm_dp~output_o\ : std_logic;
SIGNAL \o_mux_row_or_digit[0]~output_o\ : std_logic;
SIGNAL \o_mux_row_or_digit[1]~output_o\ : std_logic;
SIGNAL \o_mux_row_or_digit[2]~output_o\ : std_logic;
SIGNAL \o_mux_sel_color_or_7segm[0]~output_o\ : std_logic;
SIGNAL \o_mux_sel_color_or_7segm[1]~output_o\ : std_logic;
SIGNAL \i_sw[0]~input_o\ : std_logic;
SIGNAL \i_sw[1]~input_o\ : std_logic;
SIGNAL \i_sw[2]~input_o\ : std_logic;
SIGNAL \i_sw[3]~input_o\ : std_logic;
SIGNAL \i_sw[4]~input_o\ : std_logic;
SIGNAL \i_sw[5]~input_o\ : std_logic;
SIGNAL \i_sw[6]~input_o\ : std_logic;
SIGNAL \i_sw[7]~input_o\ : std_logic;
SIGNAL \i_pb_up~input_o\ : std_logic;
SIGNAL \i_pb_center~input_o\ : std_logic;
SIGNAL \i_pb_left~input_o\ : std_logic;
SIGNAL \i_clk~input_o\ : std_logic;
SIGNAL \i_clk~inputclkctrl_outclk\ : std_logic;
SIGNAL \i_pb_rst~input_o\ : std_logic;
SIGNAL \uut|s_cnt1~3_combout\ : std_logic;
SIGNAL \uut|s_cnt_1us[0]~8_combout\ : std_logic;
SIGNAL \uut|s_cnt_1us[4]~21\ : std_logic;
SIGNAL \uut|s_cnt_1us[5]~22_combout\ : std_logic;
SIGNAL \uut|s_en_1us~0_combout\ : std_logic;
SIGNAL \uut|s_en_1us~q\ : std_logic;
SIGNAL \uut|s_cnt_1us[7]~19_combout\ : std_logic;
SIGNAL \uut|s_cnt_1us[5]~23\ : std_logic;
SIGNAL \uut|s_cnt_1us[6]~24_combout\ : std_logic;
SIGNAL \uut|s_cnt_1us[6]~25\ : std_logic;
SIGNAL \uut|s_cnt_1us[7]~26_combout\ : std_logic;
SIGNAL \uut|s_cnt_1us[7]~16_combout\ : std_logic;
SIGNAL \uut|s_cnt_1us[7]~17_combout\ : std_logic;
SIGNAL \uut|s_cnt_1us[7]~18_combout\ : std_logic;
SIGNAL \uut|s_cnt_1us[0]~9\ : std_logic;
SIGNAL \uut|s_cnt_1us[1]~10_combout\ : std_logic;
SIGNAL \uut|s_cnt_1us[1]~11\ : std_logic;
SIGNAL \uut|s_cnt_1us[2]~12_combout\ : std_logic;
SIGNAL \uut|s_cnt_1us[2]~13\ : std_logic;
SIGNAL \uut|s_cnt_1us[3]~14_combout\ : std_logic;
SIGNAL \uut|s_cnt_1us[3]~15\ : std_logic;
SIGNAL \uut|s_cnt_1us[4]~20_combout\ : std_logic;
SIGNAL \uut|s_en0~0_combout\ : std_logic;
SIGNAL \uut|s_en0~1_combout\ : std_logic;
SIGNAL \uut|s_cnt0~0_combout\ : std_logic;
SIGNAL \uut|s_cnt0[3]~1_combout\ : std_logic;
SIGNAL \uut|s_cnt0~2_combout\ : std_logic;
SIGNAL \uut|s_cnt0~3_combout\ : std_logic;
SIGNAL \uut|s_cnt1[3]~1_combout\ : std_logic;
SIGNAL \uut|s_cnt1[3]~2_combout\ : std_logic;
SIGNAL \uut|s_cnt1~4_combout\ : std_logic;
SIGNAL \uut|s_cnt1~0_combout\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[0]~16_combout\ : std_logic;
SIGNAL \in_rst~input_o\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[0]~17\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[1]~18_combout\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[1]~19\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[2]~20_combout\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[2]~21\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[3]~22_combout\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[3]~23\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[4]~24_combout\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[4]~25\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[5]~26_combout\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[5]~27\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[6]~28_combout\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[6]~29\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[7]~30_combout\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[7]~31\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[8]~32_combout\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[8]~33\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[9]~34_combout\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[9]~35\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[10]~36_combout\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[10]~37\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[11]~38_combout\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[11]~39\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[12]~40_combout\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[12]~41\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[13]~42_combout\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[13]~43\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[14]~44_combout\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[14]~45\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt[15]~46_combout\ : std_logic;
SIGNAL \Mux3~0_combout\ : std_logic;
SIGNAL \Mux2~0_combout\ : std_logic;
SIGNAL \Mux0~0_combout\ : std_logic;
SIGNAL \Mux1~0_combout\ : std_logic;
SIGNAL \Mux4~0_combout\ : std_logic;
SIGNAL \Mux6~0_combout\ : std_logic;
SIGNAL \Mux9~0_combout\ : std_logic;
SIGNAL \Mux10~0_combout\ : std_logic;
SIGNAL \Mux8~0_combout\ : std_logic;
SIGNAL \Mux5~0_combout\ : std_logic;
SIGNAL \Mux7~0_combout\ : std_logic;
SIGNAL \digit_sel_cnt_inst|cnt\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \uut|s_cnt_1us\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \uut|s_cnt1\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \uut|s_cnt0\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \ALT_INV_Mux7~0_combout\ : std_logic;
SIGNAL \ALT_INV_Mux3~0_combout\ : std_logic;

COMPONENT hard_block
    PORT (
	devoe : IN std_logic;
	devclrn : IN std_logic;
	devpor : IN std_logic);
END COMPONENT;

BEGIN

ww_i_clk <= i_clk;
ww_in_rst <= in_rst;
o_led <= ww_o_led;
o_sem_r <= ww_o_sem_r;
o_sem_y <= ww_o_sem_y;
o_sem_g <= ww_o_sem_g;
o_n_col_0_or_7segm_a <= ww_o_n_col_0_or_7segm_a;
o_n_col_1_or_7segm_b <= ww_o_n_col_1_or_7segm_b;
o_n_col_2_or_7segm_c <= ww_o_n_col_2_or_7segm_c;
o_n_col_3_or_7segm_d <= ww_o_n_col_3_or_7segm_d;
o_n_col_4_or_7segm_e <= ww_o_n_col_4_or_7segm_e;
o_n_col_5_or_7segm_f <= ww_o_n_col_5_or_7segm_f;
o_n_col_6_or_7segm_g <= ww_o_n_col_6_or_7segm_g;
o_n_col_7_or_7segm_dp <= ww_o_n_col_7_or_7segm_dp;
o_mux_row_or_digit <= ww_o_mux_row_or_digit;
o_mux_sel_color_or_7segm <= ww_o_mux_sel_color_or_7segm;
ww_i_sw <= i_sw;
ww_i_pb_up <= i_pb_up;
ww_i_pb_center <= i_pb_center;
ww_i_pb_down <= i_pb_down;
ww_i_pb_left <= i_pb_left;
ww_i_pb_right <= i_pb_right;
ww_i_pb_rst <= i_pb_rst;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\~QUARTUS_CREATED_ADC1~_CHSEL_bus\ <= (\~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\);

\i_clk~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \i_clk~input_o\);
\ALT_INV_Mux7~0_combout\ <= NOT \Mux7~0_combout\;
\ALT_INV_Mux3~0_combout\ <= NOT \Mux3~0_combout\;
auto_generated_inst : hard_block
PORT MAP (
	devoe => ww_devoe,
	devclrn => ww_devclrn,
	devpor => ww_devpor);

-- Location: LCCOMB_X26_Y19_N12
\~QUARTUS_CREATED_GND~I\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \~QUARTUS_CREATED_GND~I_combout\ = GND

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	combout => \~QUARTUS_CREATED_GND~I_combout\);

-- Location: IOOBUF_X19_Y17_N9
\o_led[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \i_sw[0]~input_o\,
	devoe => ww_devoe,
	o => \o_led[0]~output_o\);

-- Location: IOOBUF_X19_Y17_N16
\o_led[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \i_sw[1]~input_o\,
	devoe => ww_devoe,
	o => \o_led[1]~output_o\);

-- Location: IOOBUF_X16_Y17_N9
\o_led[2]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \i_sw[2]~input_o\,
	devoe => ww_devoe,
	o => \o_led[2]~output_o\);

-- Location: IOOBUF_X16_Y17_N2
\o_led[3]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \i_sw[3]~input_o\,
	devoe => ww_devoe,
	o => \o_led[3]~output_o\);

-- Location: IOOBUF_X19_Y17_N23
\o_led[4]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \i_sw[4]~input_o\,
	devoe => ww_devoe,
	o => \o_led[4]~output_o\);

-- Location: IOOBUF_X19_Y17_N2
\o_led[5]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \i_sw[5]~input_o\,
	devoe => ww_devoe,
	o => \o_led[5]~output_o\);

-- Location: IOOBUF_X21_Y17_N30
\o_led[6]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \i_sw[6]~input_o\,
	devoe => ww_devoe,
	o => \o_led[6]~output_o\);

-- Location: IOOBUF_X16_Y17_N16
\o_led[7]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \i_sw[7]~input_o\,
	devoe => ww_devoe,
	o => \o_led[7]~output_o\);

-- Location: IOOBUF_X50_Y10_N2
\o_sem_r~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \i_pb_up~input_o\,
	devoe => ww_devoe,
	o => \o_sem_r~output_o\);

-- Location: IOOBUF_X25_Y24_N23
\o_sem_y~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \i_pb_center~input_o\,
	devoe => ww_devoe,
	o => \o_sem_y~output_o\);

-- Location: IOOBUF_X25_Y23_N23
\o_sem_g~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \i_pb_left~input_o\,
	devoe => ww_devoe,
	o => \o_sem_g~output_o\);

-- Location: IOOBUF_X50_Y11_N16
\o_n_col_0_or_7segm_a~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \Mux4~0_combout\,
	devoe => ww_devoe,
	o => \o_n_col_0_or_7segm_a~output_o\);

-- Location: IOOBUF_X50_Y2_N23
\o_n_col_1_or_7segm_b~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \Mux6~0_combout\,
	devoe => ww_devoe,
	o => \o_n_col_1_or_7segm_b~output_o\);

-- Location: IOOBUF_X0_Y8_N16
\o_n_col_2_or_7segm_c~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \Mux9~0_combout\,
	devoe => ww_devoe,
	o => \o_n_col_2_or_7segm_c~output_o\);

-- Location: IOOBUF_X0_Y8_N23
\o_n_col_3_or_7segm_d~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \Mux10~0_combout\,
	devoe => ww_devoe,
	o => \o_n_col_3_or_7segm_d~output_o\);

-- Location: IOOBUF_X0_Y9_N2
\o_n_col_4_or_7segm_e~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \Mux8~0_combout\,
	devoe => ww_devoe,
	o => \o_n_col_4_or_7segm_e~output_o\);

-- Location: IOOBUF_X0_Y9_N9
\o_n_col_5_or_7segm_f~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \Mux5~0_combout\,
	devoe => ww_devoe,
	o => \o_n_col_5_or_7segm_f~output_o\);

-- Location: IOOBUF_X50_Y2_N2
\o_n_col_6_or_7segm_g~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ALT_INV_Mux7~0_combout\,
	devoe => ww_devoe,
	o => \o_n_col_6_or_7segm_g~output_o\);

-- Location: IOOBUF_X50_Y8_N16
\o_n_col_7_or_7segm_dp~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ALT_INV_Mux3~0_combout\,
	devoe => ww_devoe,
	o => \o_n_col_7_or_7segm_dp~output_o\);

-- Location: IOOBUF_X50_Y10_N9
\o_mux_row_or_digit[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \digit_sel_cnt_inst|cnt\(14),
	devoe => ww_devoe,
	o => \o_mux_row_or_digit[0]~output_o\);

-- Location: IOOBUF_X50_Y2_N9
\o_mux_row_or_digit[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \digit_sel_cnt_inst|cnt\(15),
	devoe => ww_devoe,
	o => \o_mux_row_or_digit[1]~output_o\);

-- Location: IOOBUF_X50_Y8_N23
\o_mux_row_or_digit[2]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \o_mux_row_or_digit[2]~output_o\);

-- Location: IOOBUF_X50_Y2_N16
\o_mux_sel_color_or_7segm[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => VCC,
	devoe => ww_devoe,
	o => \o_mux_sel_color_or_7segm[0]~output_o\);

-- Location: IOOBUF_X50_Y10_N16
\o_mux_sel_color_or_7segm[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => VCC,
	devoe => ww_devoe,
	o => \o_mux_sel_color_or_7segm[1]~output_o\);

-- Location: IOIBUF_X0_Y3_N15
\i_sw[0]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_i_sw(0),
	o => \i_sw[0]~input_o\);

-- Location: IOIBUF_X0_Y3_N22
\i_sw[1]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_i_sw(1),
	o => \i_sw[1]~input_o\);

-- Location: IOIBUF_X0_Y8_N8
\i_sw[2]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_i_sw(2),
	o => \i_sw[2]~input_o\);

-- Location: IOIBUF_X0_Y8_N1
\i_sw[3]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_i_sw(3),
	o => \i_sw[3]~input_o\);

-- Location: IOIBUF_X0_Y7_N22
\i_sw[4]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_i_sw(4),
	o => \i_sw[4]~input_o\);

-- Location: IOIBUF_X0_Y7_N15
\i_sw[5]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_i_sw(5),
	o => \i_sw[5]~input_o\);

-- Location: IOIBUF_X0_Y3_N8
\i_sw[6]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_i_sw(6),
	o => \i_sw[6]~input_o\);

-- Location: IOIBUF_X0_Y3_N1
\i_sw[7]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_i_sw(7),
	o => \i_sw[7]~input_o\);

-- Location: IOIBUF_X25_Y22_N22
\i_pb_up~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_i_pb_up,
	o => \i_pb_up~input_o\);

-- Location: IOIBUF_X25_Y25_N22
\i_pb_center~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_i_pb_center,
	o => \i_pb_center~input_o\);

-- Location: IOIBUF_X25_Y25_N15
\i_pb_left~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_i_pb_left,
	o => \i_pb_left~input_o\);

-- Location: IOIBUF_X0_Y9_N22
\i_clk~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_i_clk,
	o => \i_clk~input_o\);

-- Location: CLKCTRL_G4
\i_clk~inputclkctrl\ : fiftyfivenm_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \i_clk~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \i_clk~inputclkctrl_outclk\);

-- Location: IOIBUF_X25_Y22_N15
\i_pb_rst~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_i_pb_rst,
	o => \i_pb_rst~input_o\);

-- Location: LCCOMB_X27_Y19_N8
\uut|s_cnt1~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \uut|s_cnt1~3_combout\ = (!\i_pb_rst~input_o\ & (!\uut|s_cnt1\(2) & (\uut|s_cnt1\(0) $ (\uut|s_cnt1\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \i_pb_rst~input_o\,
	datab => \uut|s_cnt1\(0),
	datac => \uut|s_cnt1\(1),
	datad => \uut|s_cnt1\(2),
	combout => \uut|s_cnt1~3_combout\);

-- Location: LCCOMB_X27_Y19_N14
\uut|s_cnt_1us[0]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \uut|s_cnt_1us[0]~8_combout\ = \uut|s_cnt_1us\(0) $ (VCC)
-- \uut|s_cnt_1us[0]~9\ = CARRY(\uut|s_cnt_1us\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \uut|s_cnt_1us\(0),
	datad => VCC,
	combout => \uut|s_cnt_1us[0]~8_combout\,
	cout => \uut|s_cnt_1us[0]~9\);

-- Location: LCCOMB_X27_Y19_N22
\uut|s_cnt_1us[4]~20\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \uut|s_cnt_1us[4]~20_combout\ = (\uut|s_cnt_1us\(4) & (\uut|s_cnt_1us[3]~15\ $ (GND))) # (!\uut|s_cnt_1us\(4) & (!\uut|s_cnt_1us[3]~15\ & VCC))
-- \uut|s_cnt_1us[4]~21\ = CARRY((\uut|s_cnt_1us\(4) & !\uut|s_cnt_1us[3]~15\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \uut|s_cnt_1us\(4),
	datad => VCC,
	cin => \uut|s_cnt_1us[3]~15\,
	combout => \uut|s_cnt_1us[4]~20_combout\,
	cout => \uut|s_cnt_1us[4]~21\);

-- Location: LCCOMB_X27_Y19_N24
\uut|s_cnt_1us[5]~22\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \uut|s_cnt_1us[5]~22_combout\ = (\uut|s_cnt_1us\(5) & (!\uut|s_cnt_1us[4]~21\)) # (!\uut|s_cnt_1us\(5) & ((\uut|s_cnt_1us[4]~21\) # (GND)))
-- \uut|s_cnt_1us[5]~23\ = CARRY((!\uut|s_cnt_1us[4]~21\) # (!\uut|s_cnt_1us\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \uut|s_cnt_1us\(5),
	datad => VCC,
	cin => \uut|s_cnt_1us[4]~21\,
	combout => \uut|s_cnt_1us[5]~22_combout\,
	cout => \uut|s_cnt_1us[5]~23\);

-- Location: LCCOMB_X26_Y19_N6
\uut|s_en_1us~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \uut|s_en_1us~0_combout\ = (!\i_pb_rst~input_o\ & ((\i_pb_left~input_o\) # ((\uut|s_en_1us~q\ & !\i_pb_center~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100010001010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \i_pb_rst~input_o\,
	datab => \i_pb_left~input_o\,
	datac => \uut|s_en_1us~q\,
	datad => \i_pb_center~input_o\,
	combout => \uut|s_en_1us~0_combout\);

-- Location: FF_X26_Y19_N7
\uut|s_en_1us\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \uut|s_en_1us~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \uut|s_en_1us~q\);

-- Location: LCCOMB_X26_Y19_N2
\uut|s_cnt_1us[7]~19\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \uut|s_cnt_1us[7]~19_combout\ = (\i_pb_rst~input_o\) # (\uut|s_en_1us~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \i_pb_rst~input_o\,
	datad => \uut|s_en_1us~q\,
	combout => \uut|s_cnt_1us[7]~19_combout\);

-- Location: FF_X27_Y19_N25
\uut|s_cnt_1us[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \uut|s_cnt_1us[5]~22_combout\,
	sclr => \uut|s_cnt_1us[7]~18_combout\,
	ena => \uut|s_cnt_1us[7]~19_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \uut|s_cnt_1us\(5));

-- Location: LCCOMB_X27_Y19_N26
\uut|s_cnt_1us[6]~24\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \uut|s_cnt_1us[6]~24_combout\ = (\uut|s_cnt_1us\(6) & (\uut|s_cnt_1us[5]~23\ $ (GND))) # (!\uut|s_cnt_1us\(6) & (!\uut|s_cnt_1us[5]~23\ & VCC))
-- \uut|s_cnt_1us[6]~25\ = CARRY((\uut|s_cnt_1us\(6) & !\uut|s_cnt_1us[5]~23\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \uut|s_cnt_1us\(6),
	datad => VCC,
	cin => \uut|s_cnt_1us[5]~23\,
	combout => \uut|s_cnt_1us[6]~24_combout\,
	cout => \uut|s_cnt_1us[6]~25\);

-- Location: FF_X27_Y19_N27
\uut|s_cnt_1us[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \uut|s_cnt_1us[6]~24_combout\,
	sclr => \uut|s_cnt_1us[7]~18_combout\,
	ena => \uut|s_cnt_1us[7]~19_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \uut|s_cnt_1us\(6));

-- Location: LCCOMB_X27_Y19_N28
\uut|s_cnt_1us[7]~26\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \uut|s_cnt_1us[7]~26_combout\ = \uut|s_cnt_1us[6]~25\ $ (\uut|s_cnt_1us\(7))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => \uut|s_cnt_1us\(7),
	cin => \uut|s_cnt_1us[6]~25\,
	combout => \uut|s_cnt_1us[7]~26_combout\);

-- Location: FF_X27_Y19_N29
\uut|s_cnt_1us[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \uut|s_cnt_1us[7]~26_combout\,
	sclr => \uut|s_cnt_1us[7]~18_combout\,
	ena => \uut|s_cnt_1us[7]~19_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \uut|s_cnt_1us\(7));

-- Location: LCCOMB_X27_Y19_N10
\uut|s_cnt_1us[7]~16\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \uut|s_cnt_1us[7]~16_combout\ = (!\i_pb_rst~input_o\ & (((!\uut|s_cnt_1us\(1)) # (!\uut|s_cnt_1us\(0))) # (!\uut|s_cnt_1us\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001010101010101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \i_pb_rst~input_o\,
	datab => \uut|s_cnt_1us\(2),
	datac => \uut|s_cnt_1us\(0),
	datad => \uut|s_cnt_1us\(1),
	combout => \uut|s_cnt_1us[7]~16_combout\);

-- Location: LCCOMB_X27_Y19_N12
\uut|s_cnt_1us[7]~17\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \uut|s_cnt_1us[7]~17_combout\ = (\uut|s_cnt_1us[7]~16_combout\ & (!\uut|s_cnt_1us\(3) & (!\uut|s_cnt_1us\(4) & !\uut|s_cnt_1us\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \uut|s_cnt_1us[7]~16_combout\,
	datab => \uut|s_cnt_1us\(3),
	datac => \uut|s_cnt_1us\(4),
	datad => \uut|s_cnt_1us\(5),
	combout => \uut|s_cnt_1us[7]~17_combout\);

-- Location: LCCOMB_X27_Y19_N30
\uut|s_cnt_1us[7]~18\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \uut|s_cnt_1us[7]~18_combout\ = (!\uut|s_cnt_1us[7]~17_combout\ & ((\i_pb_rst~input_o\) # ((\uut|s_cnt_1us\(7) & \uut|s_cnt_1us\(6)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \i_pb_rst~input_o\,
	datab => \uut|s_cnt_1us\(7),
	datac => \uut|s_cnt_1us\(6),
	datad => \uut|s_cnt_1us[7]~17_combout\,
	combout => \uut|s_cnt_1us[7]~18_combout\);

-- Location: FF_X27_Y19_N15
\uut|s_cnt_1us[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \uut|s_cnt_1us[0]~8_combout\,
	sclr => \uut|s_cnt_1us[7]~18_combout\,
	ena => \uut|s_cnt_1us[7]~19_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \uut|s_cnt_1us\(0));

-- Location: LCCOMB_X27_Y19_N16
\uut|s_cnt_1us[1]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \uut|s_cnt_1us[1]~10_combout\ = (\uut|s_cnt_1us\(1) & (!\uut|s_cnt_1us[0]~9\)) # (!\uut|s_cnt_1us\(1) & ((\uut|s_cnt_1us[0]~9\) # (GND)))
-- \uut|s_cnt_1us[1]~11\ = CARRY((!\uut|s_cnt_1us[0]~9\) # (!\uut|s_cnt_1us\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \uut|s_cnt_1us\(1),
	datad => VCC,
	cin => \uut|s_cnt_1us[0]~9\,
	combout => \uut|s_cnt_1us[1]~10_combout\,
	cout => \uut|s_cnt_1us[1]~11\);

-- Location: FF_X27_Y19_N17
\uut|s_cnt_1us[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \uut|s_cnt_1us[1]~10_combout\,
	sclr => \uut|s_cnt_1us[7]~18_combout\,
	ena => \uut|s_cnt_1us[7]~19_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \uut|s_cnt_1us\(1));

-- Location: LCCOMB_X27_Y19_N18
\uut|s_cnt_1us[2]~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \uut|s_cnt_1us[2]~12_combout\ = (\uut|s_cnt_1us\(2) & (\uut|s_cnt_1us[1]~11\ $ (GND))) # (!\uut|s_cnt_1us\(2) & (!\uut|s_cnt_1us[1]~11\ & VCC))
-- \uut|s_cnt_1us[2]~13\ = CARRY((\uut|s_cnt_1us\(2) & !\uut|s_cnt_1us[1]~11\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \uut|s_cnt_1us\(2),
	datad => VCC,
	cin => \uut|s_cnt_1us[1]~11\,
	combout => \uut|s_cnt_1us[2]~12_combout\,
	cout => \uut|s_cnt_1us[2]~13\);

-- Location: FF_X27_Y19_N19
\uut|s_cnt_1us[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \uut|s_cnt_1us[2]~12_combout\,
	sclr => \uut|s_cnt_1us[7]~18_combout\,
	ena => \uut|s_cnt_1us[7]~19_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \uut|s_cnt_1us\(2));

-- Location: LCCOMB_X27_Y19_N20
\uut|s_cnt_1us[3]~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \uut|s_cnt_1us[3]~14_combout\ = (\uut|s_cnt_1us\(3) & (!\uut|s_cnt_1us[2]~13\)) # (!\uut|s_cnt_1us\(3) & ((\uut|s_cnt_1us[2]~13\) # (GND)))
-- \uut|s_cnt_1us[3]~15\ = CARRY((!\uut|s_cnt_1us[2]~13\) # (!\uut|s_cnt_1us\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \uut|s_cnt_1us\(3),
	datad => VCC,
	cin => \uut|s_cnt_1us[2]~13\,
	combout => \uut|s_cnt_1us[3]~14_combout\,
	cout => \uut|s_cnt_1us[3]~15\);

-- Location: FF_X27_Y19_N21
\uut|s_cnt_1us[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \uut|s_cnt_1us[3]~14_combout\,
	sclr => \uut|s_cnt_1us[7]~18_combout\,
	ena => \uut|s_cnt_1us[7]~19_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \uut|s_cnt_1us\(3));

-- Location: FF_X27_Y19_N23
\uut|s_cnt_1us[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \uut|s_cnt_1us[4]~20_combout\,
	sclr => \uut|s_cnt_1us[7]~18_combout\,
	ena => \uut|s_cnt_1us[7]~19_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \uut|s_cnt_1us\(4));

-- Location: LCCOMB_X27_Y19_N2
\uut|s_en0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \uut|s_en0~0_combout\ = (\uut|s_cnt_1us\(4)) # ((\uut|s_cnt_1us\(3)) # ((\uut|s_cnt_1us\(5)) # (!\uut|s_en_1us~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111101111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \uut|s_cnt_1us\(4),
	datab => \uut|s_cnt_1us\(3),
	datac => \uut|s_en_1us~q\,
	datad => \uut|s_cnt_1us\(5),
	combout => \uut|s_en0~0_combout\);

-- Location: LCCOMB_X27_Y19_N4
\uut|s_en0~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \uut|s_en0~1_combout\ = (\uut|s_cnt_1us\(6)) # ((\uut|s_cnt_1us\(2)) # ((\uut|s_cnt_1us\(0)) # (\uut|s_cnt_1us\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \uut|s_cnt_1us\(6),
	datab => \uut|s_cnt_1us\(2),
	datac => \uut|s_cnt_1us\(0),
	datad => \uut|s_cnt_1us\(1),
	combout => \uut|s_en0~1_combout\);

-- Location: LCCOMB_X26_Y19_N24
\uut|s_cnt0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \uut|s_cnt0~0_combout\ = (!\i_pb_rst~input_o\ & !\uut|s_cnt0\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010100000101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \i_pb_rst~input_o\,
	datac => \uut|s_cnt0\(0),
	combout => \uut|s_cnt0~0_combout\);

-- Location: LCCOMB_X26_Y19_N8
\uut|s_cnt0[3]~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \uut|s_cnt0[3]~1_combout\ = (\i_pb_rst~input_o\) # ((!\uut|s_en0~0_combout\ & (!\uut|s_cnt_1us\(7) & !\uut|s_en0~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \uut|s_en0~0_combout\,
	datab => \uut|s_cnt_1us\(7),
	datac => \i_pb_rst~input_o\,
	datad => \uut|s_en0~1_combout\,
	combout => \uut|s_cnt0[3]~1_combout\);

-- Location: FF_X26_Y19_N25
\uut|s_cnt0[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \uut|s_cnt0~0_combout\,
	ena => \uut|s_cnt0[3]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \uut|s_cnt0\(0));

-- Location: LCCOMB_X26_Y19_N10
\uut|s_cnt0~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \uut|s_cnt0~2_combout\ = (!\i_pb_rst~input_o\ & (\uut|s_cnt0\(1) $ (\uut|s_cnt0\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010101010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \i_pb_rst~input_o\,
	datac => \uut|s_cnt0\(1),
	datad => \uut|s_cnt0\(0),
	combout => \uut|s_cnt0~2_combout\);

-- Location: FF_X26_Y19_N11
\uut|s_cnt0[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \uut|s_cnt0~2_combout\,
	ena => \uut|s_cnt0[3]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \uut|s_cnt0\(1));

-- Location: LCCOMB_X26_Y19_N4
\uut|s_cnt0~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \uut|s_cnt0~3_combout\ = (!\i_pb_rst~input_o\ & (\uut|s_cnt0\(2) $ (((\uut|s_cnt0\(0) & \uut|s_cnt0\(1))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001010001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \i_pb_rst~input_o\,
	datab => \uut|s_cnt0\(0),
	datac => \uut|s_cnt0\(2),
	datad => \uut|s_cnt0\(1),
	combout => \uut|s_cnt0~3_combout\);

-- Location: FF_X26_Y19_N5
\uut|s_cnt0[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \uut|s_cnt0~3_combout\,
	ena => \uut|s_cnt0[3]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \uut|s_cnt0\(2));

-- Location: LCCOMB_X27_Y19_N6
\uut|s_cnt1[3]~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \uut|s_cnt1[3]~1_combout\ = (\uut|s_cnt0\(1) & (\uut|s_cnt0\(0) & (\uut|s_cnt0\(2) & !\uut|s_cnt_1us\(7))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \uut|s_cnt0\(1),
	datab => \uut|s_cnt0\(0),
	datac => \uut|s_cnt0\(2),
	datad => \uut|s_cnt_1us\(7),
	combout => \uut|s_cnt1[3]~1_combout\);

-- Location: LCCOMB_X27_Y19_N0
\uut|s_cnt1[3]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \uut|s_cnt1[3]~2_combout\ = (\i_pb_rst~input_o\) # ((!\uut|s_en0~0_combout\ & (!\uut|s_en0~1_combout\ & \uut|s_cnt1[3]~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \i_pb_rst~input_o\,
	datab => \uut|s_en0~0_combout\,
	datac => \uut|s_en0~1_combout\,
	datad => \uut|s_cnt1[3]~1_combout\,
	combout => \uut|s_cnt1[3]~2_combout\);

-- Location: FF_X27_Y19_N9
\uut|s_cnt1[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \uut|s_cnt1~3_combout\,
	ena => \uut|s_cnt1[3]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \uut|s_cnt1\(1));

-- Location: LCCOMB_X28_Y19_N18
\uut|s_cnt1~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \uut|s_cnt1~4_combout\ = (!\i_pb_rst~input_o\ & ((\uut|s_cnt1\(0) & (!\uut|s_cnt1\(2) & \uut|s_cnt1\(1))) # (!\uut|s_cnt1\(0) & (\uut|s_cnt1\(2) & !\uut|s_cnt1\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010000010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \i_pb_rst~input_o\,
	datab => \uut|s_cnt1\(0),
	datac => \uut|s_cnt1\(2),
	datad => \uut|s_cnt1\(1),
	combout => \uut|s_cnt1~4_combout\);

-- Location: FF_X28_Y19_N19
\uut|s_cnt1[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \uut|s_cnt1~4_combout\,
	ena => \uut|s_cnt1[3]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \uut|s_cnt1\(2));

-- Location: LCCOMB_X28_Y19_N8
\uut|s_cnt1~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \uut|s_cnt1~0_combout\ = (!\i_pb_rst~input_o\ & (!\uut|s_cnt1\(0) & ((!\uut|s_cnt1\(1)) # (!\uut|s_cnt1\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000100000101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \i_pb_rst~input_o\,
	datab => \uut|s_cnt1\(2),
	datac => \uut|s_cnt1\(0),
	datad => \uut|s_cnt1\(1),
	combout => \uut|s_cnt1~0_combout\);

-- Location: FF_X28_Y19_N9
\uut|s_cnt1[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \uut|s_cnt1~0_combout\,
	ena => \uut|s_cnt1[3]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \uut|s_cnt1\(0));

-- Location: LCCOMB_X29_Y19_N0
\digit_sel_cnt_inst|cnt[0]~16\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \digit_sel_cnt_inst|cnt[0]~16_combout\ = \digit_sel_cnt_inst|cnt\(0) $ (VCC)
-- \digit_sel_cnt_inst|cnt[0]~17\ = CARRY(\digit_sel_cnt_inst|cnt\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \digit_sel_cnt_inst|cnt\(0),
	datad => VCC,
	combout => \digit_sel_cnt_inst|cnt[0]~16_combout\,
	cout => \digit_sel_cnt_inst|cnt[0]~17\);

-- Location: IOIBUF_X12_Y17_N29
\in_rst~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_in_rst,
	o => \in_rst~input_o\);

-- Location: FF_X29_Y19_N1
\digit_sel_cnt_inst|cnt[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \digit_sel_cnt_inst|cnt[0]~16_combout\,
	clrn => \in_rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \digit_sel_cnt_inst|cnt\(0));

-- Location: LCCOMB_X29_Y19_N2
\digit_sel_cnt_inst|cnt[1]~18\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \digit_sel_cnt_inst|cnt[1]~18_combout\ = (\digit_sel_cnt_inst|cnt\(1) & (!\digit_sel_cnt_inst|cnt[0]~17\)) # (!\digit_sel_cnt_inst|cnt\(1) & ((\digit_sel_cnt_inst|cnt[0]~17\) # (GND)))
-- \digit_sel_cnt_inst|cnt[1]~19\ = CARRY((!\digit_sel_cnt_inst|cnt[0]~17\) # (!\digit_sel_cnt_inst|cnt\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \digit_sel_cnt_inst|cnt\(1),
	datad => VCC,
	cin => \digit_sel_cnt_inst|cnt[0]~17\,
	combout => \digit_sel_cnt_inst|cnt[1]~18_combout\,
	cout => \digit_sel_cnt_inst|cnt[1]~19\);

-- Location: FF_X29_Y19_N3
\digit_sel_cnt_inst|cnt[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \digit_sel_cnt_inst|cnt[1]~18_combout\,
	clrn => \in_rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \digit_sel_cnt_inst|cnt\(1));

-- Location: LCCOMB_X29_Y19_N4
\digit_sel_cnt_inst|cnt[2]~20\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \digit_sel_cnt_inst|cnt[2]~20_combout\ = (\digit_sel_cnt_inst|cnt\(2) & (\digit_sel_cnt_inst|cnt[1]~19\ $ (GND))) # (!\digit_sel_cnt_inst|cnt\(2) & (!\digit_sel_cnt_inst|cnt[1]~19\ & VCC))
-- \digit_sel_cnt_inst|cnt[2]~21\ = CARRY((\digit_sel_cnt_inst|cnt\(2) & !\digit_sel_cnt_inst|cnt[1]~19\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \digit_sel_cnt_inst|cnt\(2),
	datad => VCC,
	cin => \digit_sel_cnt_inst|cnt[1]~19\,
	combout => \digit_sel_cnt_inst|cnt[2]~20_combout\,
	cout => \digit_sel_cnt_inst|cnt[2]~21\);

-- Location: FF_X29_Y19_N5
\digit_sel_cnt_inst|cnt[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \digit_sel_cnt_inst|cnt[2]~20_combout\,
	clrn => \in_rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \digit_sel_cnt_inst|cnt\(2));

-- Location: LCCOMB_X29_Y19_N6
\digit_sel_cnt_inst|cnt[3]~22\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \digit_sel_cnt_inst|cnt[3]~22_combout\ = (\digit_sel_cnt_inst|cnt\(3) & (!\digit_sel_cnt_inst|cnt[2]~21\)) # (!\digit_sel_cnt_inst|cnt\(3) & ((\digit_sel_cnt_inst|cnt[2]~21\) # (GND)))
-- \digit_sel_cnt_inst|cnt[3]~23\ = CARRY((!\digit_sel_cnt_inst|cnt[2]~21\) # (!\digit_sel_cnt_inst|cnt\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \digit_sel_cnt_inst|cnt\(3),
	datad => VCC,
	cin => \digit_sel_cnt_inst|cnt[2]~21\,
	combout => \digit_sel_cnt_inst|cnt[3]~22_combout\,
	cout => \digit_sel_cnt_inst|cnt[3]~23\);

-- Location: FF_X29_Y19_N7
\digit_sel_cnt_inst|cnt[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \digit_sel_cnt_inst|cnt[3]~22_combout\,
	clrn => \in_rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \digit_sel_cnt_inst|cnt\(3));

-- Location: LCCOMB_X29_Y19_N8
\digit_sel_cnt_inst|cnt[4]~24\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \digit_sel_cnt_inst|cnt[4]~24_combout\ = (\digit_sel_cnt_inst|cnt\(4) & (\digit_sel_cnt_inst|cnt[3]~23\ $ (GND))) # (!\digit_sel_cnt_inst|cnt\(4) & (!\digit_sel_cnt_inst|cnt[3]~23\ & VCC))
-- \digit_sel_cnt_inst|cnt[4]~25\ = CARRY((\digit_sel_cnt_inst|cnt\(4) & !\digit_sel_cnt_inst|cnt[3]~23\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \digit_sel_cnt_inst|cnt\(4),
	datad => VCC,
	cin => \digit_sel_cnt_inst|cnt[3]~23\,
	combout => \digit_sel_cnt_inst|cnt[4]~24_combout\,
	cout => \digit_sel_cnt_inst|cnt[4]~25\);

-- Location: FF_X29_Y19_N9
\digit_sel_cnt_inst|cnt[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \digit_sel_cnt_inst|cnt[4]~24_combout\,
	clrn => \in_rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \digit_sel_cnt_inst|cnt\(4));

-- Location: LCCOMB_X29_Y19_N10
\digit_sel_cnt_inst|cnt[5]~26\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \digit_sel_cnt_inst|cnt[5]~26_combout\ = (\digit_sel_cnt_inst|cnt\(5) & (!\digit_sel_cnt_inst|cnt[4]~25\)) # (!\digit_sel_cnt_inst|cnt\(5) & ((\digit_sel_cnt_inst|cnt[4]~25\) # (GND)))
-- \digit_sel_cnt_inst|cnt[5]~27\ = CARRY((!\digit_sel_cnt_inst|cnt[4]~25\) # (!\digit_sel_cnt_inst|cnt\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \digit_sel_cnt_inst|cnt\(5),
	datad => VCC,
	cin => \digit_sel_cnt_inst|cnt[4]~25\,
	combout => \digit_sel_cnt_inst|cnt[5]~26_combout\,
	cout => \digit_sel_cnt_inst|cnt[5]~27\);

-- Location: FF_X29_Y19_N11
\digit_sel_cnt_inst|cnt[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \digit_sel_cnt_inst|cnt[5]~26_combout\,
	clrn => \in_rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \digit_sel_cnt_inst|cnt\(5));

-- Location: LCCOMB_X29_Y19_N12
\digit_sel_cnt_inst|cnt[6]~28\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \digit_sel_cnt_inst|cnt[6]~28_combout\ = (\digit_sel_cnt_inst|cnt\(6) & (\digit_sel_cnt_inst|cnt[5]~27\ $ (GND))) # (!\digit_sel_cnt_inst|cnt\(6) & (!\digit_sel_cnt_inst|cnt[5]~27\ & VCC))
-- \digit_sel_cnt_inst|cnt[6]~29\ = CARRY((\digit_sel_cnt_inst|cnt\(6) & !\digit_sel_cnt_inst|cnt[5]~27\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \digit_sel_cnt_inst|cnt\(6),
	datad => VCC,
	cin => \digit_sel_cnt_inst|cnt[5]~27\,
	combout => \digit_sel_cnt_inst|cnt[6]~28_combout\,
	cout => \digit_sel_cnt_inst|cnt[6]~29\);

-- Location: FF_X29_Y19_N13
\digit_sel_cnt_inst|cnt[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \digit_sel_cnt_inst|cnt[6]~28_combout\,
	clrn => \in_rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \digit_sel_cnt_inst|cnt\(6));

-- Location: LCCOMB_X29_Y19_N14
\digit_sel_cnt_inst|cnt[7]~30\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \digit_sel_cnt_inst|cnt[7]~30_combout\ = (\digit_sel_cnt_inst|cnt\(7) & (!\digit_sel_cnt_inst|cnt[6]~29\)) # (!\digit_sel_cnt_inst|cnt\(7) & ((\digit_sel_cnt_inst|cnt[6]~29\) # (GND)))
-- \digit_sel_cnt_inst|cnt[7]~31\ = CARRY((!\digit_sel_cnt_inst|cnt[6]~29\) # (!\digit_sel_cnt_inst|cnt\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \digit_sel_cnt_inst|cnt\(7),
	datad => VCC,
	cin => \digit_sel_cnt_inst|cnt[6]~29\,
	combout => \digit_sel_cnt_inst|cnt[7]~30_combout\,
	cout => \digit_sel_cnt_inst|cnt[7]~31\);

-- Location: FF_X29_Y19_N15
\digit_sel_cnt_inst|cnt[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \digit_sel_cnt_inst|cnt[7]~30_combout\,
	clrn => \in_rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \digit_sel_cnt_inst|cnt\(7));

-- Location: LCCOMB_X29_Y19_N16
\digit_sel_cnt_inst|cnt[8]~32\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \digit_sel_cnt_inst|cnt[8]~32_combout\ = (\digit_sel_cnt_inst|cnt\(8) & (\digit_sel_cnt_inst|cnt[7]~31\ $ (GND))) # (!\digit_sel_cnt_inst|cnt\(8) & (!\digit_sel_cnt_inst|cnt[7]~31\ & VCC))
-- \digit_sel_cnt_inst|cnt[8]~33\ = CARRY((\digit_sel_cnt_inst|cnt\(8) & !\digit_sel_cnt_inst|cnt[7]~31\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \digit_sel_cnt_inst|cnt\(8),
	datad => VCC,
	cin => \digit_sel_cnt_inst|cnt[7]~31\,
	combout => \digit_sel_cnt_inst|cnt[8]~32_combout\,
	cout => \digit_sel_cnt_inst|cnt[8]~33\);

-- Location: FF_X29_Y19_N17
\digit_sel_cnt_inst|cnt[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \digit_sel_cnt_inst|cnt[8]~32_combout\,
	clrn => \in_rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \digit_sel_cnt_inst|cnt\(8));

-- Location: LCCOMB_X29_Y19_N18
\digit_sel_cnt_inst|cnt[9]~34\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \digit_sel_cnt_inst|cnt[9]~34_combout\ = (\digit_sel_cnt_inst|cnt\(9) & (!\digit_sel_cnt_inst|cnt[8]~33\)) # (!\digit_sel_cnt_inst|cnt\(9) & ((\digit_sel_cnt_inst|cnt[8]~33\) # (GND)))
-- \digit_sel_cnt_inst|cnt[9]~35\ = CARRY((!\digit_sel_cnt_inst|cnt[8]~33\) # (!\digit_sel_cnt_inst|cnt\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \digit_sel_cnt_inst|cnt\(9),
	datad => VCC,
	cin => \digit_sel_cnt_inst|cnt[8]~33\,
	combout => \digit_sel_cnt_inst|cnt[9]~34_combout\,
	cout => \digit_sel_cnt_inst|cnt[9]~35\);

-- Location: FF_X29_Y19_N19
\digit_sel_cnt_inst|cnt[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \digit_sel_cnt_inst|cnt[9]~34_combout\,
	clrn => \in_rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \digit_sel_cnt_inst|cnt\(9));

-- Location: LCCOMB_X29_Y19_N20
\digit_sel_cnt_inst|cnt[10]~36\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \digit_sel_cnt_inst|cnt[10]~36_combout\ = (\digit_sel_cnt_inst|cnt\(10) & (\digit_sel_cnt_inst|cnt[9]~35\ $ (GND))) # (!\digit_sel_cnt_inst|cnt\(10) & (!\digit_sel_cnt_inst|cnt[9]~35\ & VCC))
-- \digit_sel_cnt_inst|cnt[10]~37\ = CARRY((\digit_sel_cnt_inst|cnt\(10) & !\digit_sel_cnt_inst|cnt[9]~35\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \digit_sel_cnt_inst|cnt\(10),
	datad => VCC,
	cin => \digit_sel_cnt_inst|cnt[9]~35\,
	combout => \digit_sel_cnt_inst|cnt[10]~36_combout\,
	cout => \digit_sel_cnt_inst|cnt[10]~37\);

-- Location: FF_X29_Y19_N21
\digit_sel_cnt_inst|cnt[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \digit_sel_cnt_inst|cnt[10]~36_combout\,
	clrn => \in_rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \digit_sel_cnt_inst|cnt\(10));

-- Location: LCCOMB_X29_Y19_N22
\digit_sel_cnt_inst|cnt[11]~38\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \digit_sel_cnt_inst|cnt[11]~38_combout\ = (\digit_sel_cnt_inst|cnt\(11) & (!\digit_sel_cnt_inst|cnt[10]~37\)) # (!\digit_sel_cnt_inst|cnt\(11) & ((\digit_sel_cnt_inst|cnt[10]~37\) # (GND)))
-- \digit_sel_cnt_inst|cnt[11]~39\ = CARRY((!\digit_sel_cnt_inst|cnt[10]~37\) # (!\digit_sel_cnt_inst|cnt\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \digit_sel_cnt_inst|cnt\(11),
	datad => VCC,
	cin => \digit_sel_cnt_inst|cnt[10]~37\,
	combout => \digit_sel_cnt_inst|cnt[11]~38_combout\,
	cout => \digit_sel_cnt_inst|cnt[11]~39\);

-- Location: FF_X29_Y19_N23
\digit_sel_cnt_inst|cnt[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \digit_sel_cnt_inst|cnt[11]~38_combout\,
	clrn => \in_rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \digit_sel_cnt_inst|cnt\(11));

-- Location: LCCOMB_X29_Y19_N24
\digit_sel_cnt_inst|cnt[12]~40\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \digit_sel_cnt_inst|cnt[12]~40_combout\ = (\digit_sel_cnt_inst|cnt\(12) & (\digit_sel_cnt_inst|cnt[11]~39\ $ (GND))) # (!\digit_sel_cnt_inst|cnt\(12) & (!\digit_sel_cnt_inst|cnt[11]~39\ & VCC))
-- \digit_sel_cnt_inst|cnt[12]~41\ = CARRY((\digit_sel_cnt_inst|cnt\(12) & !\digit_sel_cnt_inst|cnt[11]~39\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \digit_sel_cnt_inst|cnt\(12),
	datad => VCC,
	cin => \digit_sel_cnt_inst|cnt[11]~39\,
	combout => \digit_sel_cnt_inst|cnt[12]~40_combout\,
	cout => \digit_sel_cnt_inst|cnt[12]~41\);

-- Location: FF_X29_Y19_N25
\digit_sel_cnt_inst|cnt[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \digit_sel_cnt_inst|cnt[12]~40_combout\,
	clrn => \in_rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \digit_sel_cnt_inst|cnt\(12));

-- Location: LCCOMB_X29_Y19_N26
\digit_sel_cnt_inst|cnt[13]~42\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \digit_sel_cnt_inst|cnt[13]~42_combout\ = (\digit_sel_cnt_inst|cnt\(13) & (!\digit_sel_cnt_inst|cnt[12]~41\)) # (!\digit_sel_cnt_inst|cnt\(13) & ((\digit_sel_cnt_inst|cnt[12]~41\) # (GND)))
-- \digit_sel_cnt_inst|cnt[13]~43\ = CARRY((!\digit_sel_cnt_inst|cnt[12]~41\) # (!\digit_sel_cnt_inst|cnt\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \digit_sel_cnt_inst|cnt\(13),
	datad => VCC,
	cin => \digit_sel_cnt_inst|cnt[12]~41\,
	combout => \digit_sel_cnt_inst|cnt[13]~42_combout\,
	cout => \digit_sel_cnt_inst|cnt[13]~43\);

-- Location: FF_X29_Y19_N27
\digit_sel_cnt_inst|cnt[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \digit_sel_cnt_inst|cnt[13]~42_combout\,
	clrn => \in_rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \digit_sel_cnt_inst|cnt\(13));

-- Location: LCCOMB_X29_Y19_N28
\digit_sel_cnt_inst|cnt[14]~44\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \digit_sel_cnt_inst|cnt[14]~44_combout\ = (\digit_sel_cnt_inst|cnt\(14) & (\digit_sel_cnt_inst|cnt[13]~43\ $ (GND))) # (!\digit_sel_cnt_inst|cnt\(14) & (!\digit_sel_cnt_inst|cnt[13]~43\ & VCC))
-- \digit_sel_cnt_inst|cnt[14]~45\ = CARRY((\digit_sel_cnt_inst|cnt\(14) & !\digit_sel_cnt_inst|cnt[13]~43\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \digit_sel_cnt_inst|cnt\(14),
	datad => VCC,
	cin => \digit_sel_cnt_inst|cnt[13]~43\,
	combout => \digit_sel_cnt_inst|cnt[14]~44_combout\,
	cout => \digit_sel_cnt_inst|cnt[14]~45\);

-- Location: FF_X29_Y19_N29
\digit_sel_cnt_inst|cnt[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \digit_sel_cnt_inst|cnt[14]~44_combout\,
	clrn => \in_rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \digit_sel_cnt_inst|cnt\(14));

-- Location: LCCOMB_X29_Y19_N30
\digit_sel_cnt_inst|cnt[15]~46\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \digit_sel_cnt_inst|cnt[15]~46_combout\ = \digit_sel_cnt_inst|cnt\(15) $ (\digit_sel_cnt_inst|cnt[14]~45\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \digit_sel_cnt_inst|cnt\(15),
	cin => \digit_sel_cnt_inst|cnt[14]~45\,
	combout => \digit_sel_cnt_inst|cnt[15]~46_combout\);

-- Location: FF_X29_Y19_N31
\digit_sel_cnt_inst|cnt[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \i_clk~inputclkctrl_outclk\,
	d => \digit_sel_cnt_inst|cnt[15]~46_combout\,
	clrn => \in_rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \digit_sel_cnt_inst|cnt\(15));

-- Location: LCCOMB_X26_Y18_N16
\Mux3~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Mux3~0_combout\ = (\digit_sel_cnt_inst|cnt\(15)) # ((\digit_sel_cnt_inst|cnt\(14) & (\uut|s_cnt1\(0))) # (!\digit_sel_cnt_inst|cnt\(14) & ((\uut|s_cnt0\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \uut|s_cnt1\(0),
	datab => \uut|s_cnt0\(0),
	datac => \digit_sel_cnt_inst|cnt\(15),
	datad => \digit_sel_cnt_inst|cnt\(14),
	combout => \Mux3~0_combout\);

-- Location: LCCOMB_X26_Y18_N10
\Mux2~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Mux2~0_combout\ = (\digit_sel_cnt_inst|cnt\(15) & (((\digit_sel_cnt_inst|cnt\(14))))) # (!\digit_sel_cnt_inst|cnt\(15) & ((\digit_sel_cnt_inst|cnt\(14) & ((\uut|s_cnt1\(1)))) # (!\digit_sel_cnt_inst|cnt\(14) & (\uut|s_cnt0\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \uut|s_cnt0\(1),
	datab => \uut|s_cnt1\(1),
	datac => \digit_sel_cnt_inst|cnt\(15),
	datad => \digit_sel_cnt_inst|cnt\(14),
	combout => \Mux2~0_combout\);

-- Location: LCCOMB_X26_Y18_N30
\Mux0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Mux0~0_combout\ = (\digit_sel_cnt_inst|cnt\(15) & \digit_sel_cnt_inst|cnt\(14))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \digit_sel_cnt_inst|cnt\(15),
	datad => \digit_sel_cnt_inst|cnt\(14),
	combout => \Mux0~0_combout\);

-- Location: LCCOMB_X26_Y18_N12
\Mux1~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Mux1~0_combout\ = (\digit_sel_cnt_inst|cnt\(15) & (((\digit_sel_cnt_inst|cnt\(14))))) # (!\digit_sel_cnt_inst|cnt\(15) & ((\digit_sel_cnt_inst|cnt\(14) & (\uut|s_cnt1\(2))) # (!\digit_sel_cnt_inst|cnt\(14) & ((\uut|s_cnt0\(2))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \uut|s_cnt1\(2),
	datab => \uut|s_cnt0\(2),
	datac => \digit_sel_cnt_inst|cnt\(15),
	datad => \digit_sel_cnt_inst|cnt\(14),
	combout => \Mux1~0_combout\);

-- Location: LCCOMB_X26_Y16_N24
\Mux4~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Mux4~0_combout\ = (\Mux2~0_combout\ & (((\Mux0~0_combout\)))) # (!\Mux2~0_combout\ & (\Mux1~0_combout\ $ (((\Mux3~0_combout\ & !\Mux0~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000111000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Mux3~0_combout\,
	datab => \Mux2~0_combout\,
	datac => \Mux0~0_combout\,
	datad => \Mux1~0_combout\,
	combout => \Mux4~0_combout\);

-- Location: LCCOMB_X26_Y16_N2
\Mux6~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Mux6~0_combout\ = (\Mux0~0_combout\ & (((\Mux2~0_combout\) # (\Mux1~0_combout\)))) # (!\Mux0~0_combout\ & (\Mux1~0_combout\ & (\Mux3~0_combout\ $ (\Mux2~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Mux3~0_combout\,
	datab => \Mux2~0_combout\,
	datac => \Mux0~0_combout\,
	datad => \Mux1~0_combout\,
	combout => \Mux6~0_combout\);

-- Location: LCCOMB_X26_Y16_N12
\Mux9~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Mux9~0_combout\ = (\Mux1~0_combout\ & (((\Mux0~0_combout\)))) # (!\Mux1~0_combout\ & (\Mux2~0_combout\ & ((\Mux0~0_combout\) # (!\Mux3~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Mux3~0_combout\,
	datab => \Mux2~0_combout\,
	datac => \Mux0~0_combout\,
	datad => \Mux1~0_combout\,
	combout => \Mux9~0_combout\);

-- Location: LCCOMB_X26_Y16_N14
\Mux10~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Mux10~0_combout\ = (\Mux2~0_combout\ & ((\Mux0~0_combout\) # ((\Mux3~0_combout\ & \Mux1~0_combout\)))) # (!\Mux2~0_combout\ & (\Mux1~0_combout\ $ (((\Mux3~0_combout\ & !\Mux0~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100111000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Mux3~0_combout\,
	datab => \Mux2~0_combout\,
	datac => \Mux0~0_combout\,
	datad => \Mux1~0_combout\,
	combout => \Mux10~0_combout\);

-- Location: LCCOMB_X26_Y16_N0
\Mux8~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Mux8~0_combout\ = (\Mux3~0_combout\) # ((\Mux2~0_combout\ & (\Mux0~0_combout\)) # (!\Mux2~0_combout\ & ((\Mux1~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101111101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Mux3~0_combout\,
	datab => \Mux2~0_combout\,
	datac => \Mux0~0_combout\,
	datad => \Mux1~0_combout\,
	combout => \Mux8~0_combout\);

-- Location: LCCOMB_X26_Y16_N18
\Mux5~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Mux5~0_combout\ = (\Mux3~0_combout\ & ((\Mux2~0_combout\) # (\Mux0~0_combout\ $ (!\Mux1~0_combout\)))) # (!\Mux3~0_combout\ & ((\Mux1~0_combout\ & ((\Mux0~0_combout\))) # (!\Mux1~0_combout\ & (\Mux2~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100011001110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Mux3~0_combout\,
	datab => \Mux2~0_combout\,
	datac => \Mux0~0_combout\,
	datad => \Mux1~0_combout\,
	combout => \Mux5~0_combout\);

-- Location: LCCOMB_X26_Y16_N4
\Mux7~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Mux7~0_combout\ = (\Mux2~0_combout\ & (!\Mux0~0_combout\ & ((!\Mux1~0_combout\) # (!\Mux3~0_combout\)))) # (!\Mux2~0_combout\ & ((\Mux0~0_combout\ $ (\Mux1~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000011100111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Mux3~0_combout\,
	datab => \Mux2~0_combout\,
	datac => \Mux0~0_combout\,
	datad => \Mux1~0_combout\,
	combout => \Mux7~0_combout\);

-- Location: IOIBUF_X25_Y23_N15
\i_pb_down~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_i_pb_down,
	o => \i_pb_down~input_o\);

-- Location: IOIBUF_X25_Y24_N15
\i_pb_right~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_i_pb_right,
	o => \i_pb_right~input_o\);

-- Location: UNVM_X0_Y18_N40
\~QUARTUS_CREATED_UNVM~\ : fiftyfivenm_unvm
-- pragma translate_off
GENERIC MAP (
	addr_range1_end_addr => -1,
	addr_range1_offset => -1,
	addr_range2_offset => -1,
	is_compressed_image => "false",
	is_dual_boot => "false",
	is_eram_skip => "false",
	max_ufm_valid_addr => -1,
	max_valid_addr => -1,
	min_ufm_valid_addr => -1,
	min_valid_addr => -1,
	part_name => "quartus_created_unvm",
	reserve_block => "true")
-- pragma translate_on
PORT MAP (
	nosc_ena => \~QUARTUS_CREATED_GND~I_combout\,
	xe_ye => \~QUARTUS_CREATED_GND~I_combout\,
	se => \~QUARTUS_CREATED_GND~I_combout\,
	busy => \~QUARTUS_CREATED_UNVM~~busy\);

-- Location: ADCBLOCK_X25_Y28_N0
\~QUARTUS_CREATED_ADC1~\ : fiftyfivenm_adcblock
-- pragma translate_off
GENERIC MAP (
	analog_input_pin_mask => 0,
	clkdiv => 1,
	device_partname_fivechar_prefix => "none",
	is_this_first_or_second_adc => 1,
	prescalar => 0,
	pwd => 1,
	refsel => 0,
	reserve_block => "true",
	testbits => 66,
	tsclkdiv => 1,
	tsclksel => 0)
-- pragma translate_on
PORT MAP (
	soc => \~QUARTUS_CREATED_GND~I_combout\,
	usr_pwd => VCC,
	tsen => \~QUARTUS_CREATED_GND~I_combout\,
	chsel => \~QUARTUS_CREATED_ADC1~_CHSEL_bus\,
	eoc => \~QUARTUS_CREATED_ADC1~~eoc\);

ww_o_led(0) <= \o_led[0]~output_o\;

ww_o_led(1) <= \o_led[1]~output_o\;

ww_o_led(2) <= \o_led[2]~output_o\;

ww_o_led(3) <= \o_led[3]~output_o\;

ww_o_led(4) <= \o_led[4]~output_o\;

ww_o_led(5) <= \o_led[5]~output_o\;

ww_o_led(6) <= \o_led[6]~output_o\;

ww_o_led(7) <= \o_led[7]~output_o\;

ww_o_sem_r <= \o_sem_r~output_o\;

ww_o_sem_y <= \o_sem_y~output_o\;

ww_o_sem_g <= \o_sem_g~output_o\;

ww_o_n_col_0_or_7segm_a <= \o_n_col_0_or_7segm_a~output_o\;

ww_o_n_col_1_or_7segm_b <= \o_n_col_1_or_7segm_b~output_o\;

ww_o_n_col_2_or_7segm_c <= \o_n_col_2_or_7segm_c~output_o\;

ww_o_n_col_3_or_7segm_d <= \o_n_col_3_or_7segm_d~output_o\;

ww_o_n_col_4_or_7segm_e <= \o_n_col_4_or_7segm_e~output_o\;

ww_o_n_col_5_or_7segm_f <= \o_n_col_5_or_7segm_f~output_o\;

ww_o_n_col_6_or_7segm_g <= \o_n_col_6_or_7segm_g~output_o\;

ww_o_n_col_7_or_7segm_dp <= \o_n_col_7_or_7segm_dp~output_o\;

ww_o_mux_row_or_digit(0) <= \o_mux_row_or_digit[0]~output_o\;

ww_o_mux_row_or_digit(1) <= \o_mux_row_or_digit[1]~output_o\;

ww_o_mux_row_or_digit(2) <= \o_mux_row_or_digit[2]~output_o\;

ww_o_mux_sel_color_or_7segm(0) <= \o_mux_sel_color_or_7segm[0]~output_o\;

ww_o_mux_sel_color_or_7segm(1) <= \o_mux_sel_color_or_7segm[1]~output_o\;
END structure;


