transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vcom -93 -work work {D:/DOCs, PDFs/008 II Godina/QUARTUS/LPRS1_2/LPRS1_Homework2_RA_118_2021/LPRS1_Homework2_RA_118_2021_Solution/lprs1_homework2.vhd}
vcom -93 -work work {D:/DOCs, PDFs/008 II Godina/QUARTUS/LPRS1_2/LPRS1_Homework2_RA_118_2021/counter.vhd}
vcom -93 -work work {D:/DOCs, PDFs/008 II Godina/QUARTUS/LPRS1_2/LPRS1_Homework2_RA_118_2021/lprs1_homework2_for_board.vhd}

vcom -93 -work work {D:/DOCs, PDFs/008 II Godina/QUARTUS/LPRS1_2/LPRS1_Homework2_RA_118_2021/LPRS1_Homework2_RA_118_2021_Solution/lprs1_homework2_tb.vhd}

vsim -t 1ps -L altera -L lpm -L sgate -L altera_mf -L altera_lnsim -L fiftyfivenm -L rtl_work -L work -voptargs="+acc"  lprs1_homework2_tb

do D:/DOCs, PDFs/008 II Godina/QUARTUS/LPRS1_2/LPRS1_Homework2_RA_118_2021/lprs1_homework2_tb_run.do
