library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;

-- Libraries.

entity lprs1_homework3 is
	port(
		i_clk            :  in std_logic;
		i_rst            :  in std_logic;
		i_base           :  in std_logic_vector(1 downto 0);
		i_sequence       :  in std_logic_vector(63 downto 0);
		i_load_sequence  :  in std_logic;
		i_base_src_sel   :  in std_logic;
		i_cnt_subseq_sel :  in std_logic_vector(1 downto 0);
		o_cnt_subseq     : out std_logic_vector(3 downto 0)
	);
end entity;


architecture arch of lprs1_homework3 is
	-- Constants.
	constant A : std_logic_vector(1 downto 0) := "00";
	constant C : std_logic_vector(1 downto 0) := "01";
	constant G : std_logic_vector(1 downto 0) := "10";
	constant T : std_logic_vector(1 downto 0) := "11";
	
	-- Signals.
	type t_state is(IDLE, GXX, GAX, GGX, GAG, GGG, GGA);
	signal s_state, s_next_state : t_state;
	
	signal s_en_subseq0 	: std_logic;
	signal s_en_subseq1 	: std_logic;
	signal s_en_subseq2 	: std_logic;
	
	signal s_cnt_subseq0 : std_logic_vector(3 downto 0);	-- po modulu 8
	signal s_cnt_subseq1 : std_logic_vector(3 downto 0);	-- po modulu 5
	signal s_cnt_subseq2 : std_logic_vector(3 downto 0);  -- po modulu 7

	signal s_base 			: std_logic_vector(1 downto 0);
	signal s_sh_base 		: std_logic_vector(1 downto 0);
	signal s_sh_sequence : std_logic_vector(63 downto 0);
	signal s_sh_reg 		: std_logic_vector(63 downto 0);
	signal s_sh_reg_next : std_logic_vector(63 downto 0);

	
begin
	-- Body.
	--registar pamcenja stanja
	process(i_clk) begin
		if(rising_edge(i_clk)) then
			if(i_rst = '1') then
				s_state <= IDLE;
			else
				s_state <= s_next_state;
			end if;
		end if;
	end process;
	
	--prelazi stanja
	process(s_state,s_base) begin
		case(s_state) is
			when IDLE =>
				if(s_base = G) then
					s_next_state <= GXX;
				else
					s_next_state <= s_state;
				end if;

			when GXX =>
				if(s_base = G) then
					s_next_state <= GGX;
				elsif(s_base = A) then
					s_next_state <= GAX;
				else 
					s_next_state <= IDLE;
				end if;
			
			when GGX =>
				if(s_base = G) then
					s_next_state <= GGG;
				elsif(s_base = A) then
					s_next_state <= GGA;
				else
					s_next_state <= IDLE;
				end if;
			
			when GAX =>
				if(s_base = G) then
					s_next_state <= GAG;
				else
					s_next_state <= IDLE;
				end if;
				
			when GGG =>
				if(s_base = G) then
					s_next_state <= GXX;
				else
					s_next_state <= IDLE;
				end if;
				
			when GGA =>
				if(s_base = G) then
					s_next_state <= GXX;
				else
					s_next_state <= IDLE;
				end if;

			when GAG =>
				if(s_base = G) then
					s_next_state <= GXX;
				else
					s_next_state <= IDLE;
				end if;
		end case;
	end process;
			
--dozvola brojanja
	s_en_subseq0 <= '1' when s_state = GGG else '0';
	s_en_subseq1 <= '1' when s_state = GGA else '0';
	s_en_subseq2 <= '1' when s_state = GAG else '0';

--brojac 0. podsekvence
process(i_clk) begin
	if(rising_edge(i_clk)) then
		if(i_rst = '1') then
			s_cnt_subseq0 <= "0000";
		else
			if(s_en_subseq0 = '1') then
				if(s_cnt_subseq0 >= 8) then
					s_cnt_subseq0 <= "0000";
				elsif(s_cnt_subseq0 < 8) then
					s_cnt_subseq0 <= s_cnt_subseq0 + 1;
				end if;
			end if;
		end if;
	end if;
end process;

--brojac 1. podsekvence
process(i_clk,i_rst) begin
	if(i_rst = '1') then
		s_cnt_subseq1 <= "0000";
	elsif(rising_edge(i_clk)) then
		if(s_en_subseq1 = '1') then
			if(s_cnt_subseq1 >= 4) then
				s_cnt_subseq1 <= "0000";
			elsif(s_cnt_subseq1 < 4) then
				s_cnt_subseq1 <= s_cnt_subseq1 +1;
			end if;
		end if;
	end if;
end process;

--brojac 2. podsekvence
	
process(i_clk,i_rst) begin
	if(i_rst = '1') then
		s_cnt_subseq2 <= "0000";
	elsif(rising_edge(i_clk)) then
		if(s_en_subseq2 = '1') then
			if(s_cnt_subseq2 >= 6) then
				s_cnt_subseq2 <= "0000";
			elsif(s_cnt_subseq2 < 6)then
				s_cnt_subseq2 <= s_cnt_subseq2 + 1;
			end if;
		end if;
	end if;
end process;

--izlazni mux
o_cnt_subseq <= s_cnt_subseq0 when i_cnt_subseq_sel = "00" else 
					 s_cnt_subseq1 when i_cnt_subseq_sel = "01" else 
					 s_cnt_subseq2 when i_cnt_subseq_sel = "10" else
					 "0000";
					 
--ulazni mux
	process(i_base_src_sel, i_base, s_sh_base) begin
		case(i_base_src_sel) is
			when '0' => s_base <= i_base;
			when '1' => s_base <= s_sh_base;
			when others => s_base <= "00";
		end case;
	end process;
	
----pom reg

process(i_clk,i_rst) begin
    if(i_rst = '1') then
        s_sh_reg <= (others => '0');
    elsif(rising_edge(i_clk)) then
        s_sh_reg <= s_sh_reg_next;
    end if;
end process;

process(i_load_sequence) begin
	if(i_load_sequence = '1') then
		s_sh_reg_next <= i_sequence;
	else
		s_sh_reg_next <= s_sh_reg(61 downto 0) & "00";
	end if;
end process;
s_sh_base <= s_sh_reg(1 downto 0);

end architecture;