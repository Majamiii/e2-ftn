﻿/*
Интерпретирање међујезика у форми стабла.
Имплементација програма који пролази кроз стабло и проналази највећи број аргумената било ког print исказа.
Урађено у складу са слајдовима P7.3 Interpretiranje medjujezika.

Верзија 5: Ослањање на std::variant, као изражајнију верзију уније. У варијанти (за разлику од уније) може
бити std::string. Такође, користи се и std::visit: функција која која подржава примену пројектантског шаблона
посетиоца над варијантама. Дат је и посетилац који пролази и пребројава све чворове.
*/

#include "IR.h"
#include "ArgsVisitor.h"
#include "NodesVisitor.h"

#include <iostream>
#include <variant>

using std::cout;
using std::endl;
using std::visit;


IrStm* prog1() {
	// a := 5+3; b := (print(a, a-1), 10*a); print(b);
	return
		makeCompoundStm(
			makeAssignStm("a", makeOpExp(makeNumExp(5), OK_PLUS, makeNumExp(3))),
			makeCompoundStm(
				makeAssignStm("b", makeEseqExp(
					makePrintStm(makePairExpList(makeIdExp("a"), makeLastExpList(
						makeOpExp(makeIdExp("a"), OK_MINUS, makeNumExp(1))))),
					makeOpExp(makeNumExp(10), OK_MUL, makeIdExp("a")))),
				makePrintStm(makeLastExpList(makeIdExp("b")))
			)
		);
}


template<typename VisitorT>
int interpret(IrStm* s, VisitorT v) {
    return visit(v, *s);
}

int main()
{
	IrStm* root = prog1();
	cout << interpret(root, ArgsStmVisitor()) << endl;
	cout << interpret(root, NodesStmVisitor());

	return 0;
}
