﻿/*
Интерпретирање међујезика у форми стабла.
Имплементација програма који пролази кроз стабло и проналази највећи број аргумената било ког print исказа.
Урађено у складу са слајдовима P7.3 Interpretiranje medjujezika.

Верзија 4: Ослањање на наслеђивање (уместо на уније) и пројектантски шаблон посетиоца: функције које
обављају посао су одвојене од класа које описују чворове стабла. Посебно повољно у случају да је потребно
имплементирати више различитих пролазака кроз стабло. Због тога је додат и пролаз који пребројава све чворове.
getKind и даље у суштини не треба.
*/

#include "IR.h"
#include "ArgsVisitor.h"
#include "NodesVisitor.h"

#include <iostream>

using std::cout;
using std::endl;


IrStm* prog1() {
	// a := 5+3; b := (print(a, a-1), 10*a); print(b);
	return
		makeCompoundStm(
			makeAssignStm("a", makeOpExp(makeNumExp(5), OK_PLUS, makeNumExp(3))),
			makeCompoundStm(
				makeAssignStm("b", makeEseqExp(
					makePrintStm(makePairExpList(makeIdExp("a"), makeLastExpList(
						makeOpExp(makeIdExp("a"), OK_MINUS, makeNumExp(1))))),
					makeOpExp(makeNumExp(10), OK_MUL, makeIdExp("a")))),
				makePrintStm(makeLastExpList(makeIdExp("b")))
			)
		);
}


int main()
{
	IrStm* root = prog1();
	cout << root->accept(ArgsVisitor()) << endl;
	cout << root->accept(NodesVisitor());

	return 0;
}
